#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple test keystone driver");

static int __init keystone_init(void) {
    pr_info("Keystone driver loaded\n");
    return 0;
}

static void __exit keystone_exit(void) {
    pr_info("Keystone driver unloaded\n");
}

module_init(keystone_init);
module_exit(keystone_exit);
